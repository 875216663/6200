import java.util.Random;
import java.util.Scanner;

public class Assignment1 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number of rows:");
		int rows=sc.nextInt();
		System.out.println("Enter the number of columns:");
		int columns=sc.nextInt();
		int[][] tarrays=new int[rows][columns];
		Random random=new Random();
		
		//fill the tarrays
		for(int i=0;i<rows;i++) {
			for(int j=0;j<tarrays.length;j++) {
				tarrays[i][j]=random.nextInt(10);
			}
		}
		
		System.out.println("The array content is:");
		for(int i=0;i<tarrays.length;i++) {
			for(int j=0;j<tarrays[i].length;j++) {
				System.out.print(tarrays[i][j]+" ");
			}
			System.out.println();
		}
		//find the max value of all the rows
	
		int maxRowindex=0;
		int maxRowvalue=0;
		for(int i=0;i<rows;i++) {
			int rowsum=0;
			for(int j=0;j<columns;j++) {
				rowsum+=tarrays[i][j];
			}
			if(rowsum>maxRowvalue) {
				maxRowindex=i+1;
				maxRowvalue=rowsum;
			}
			
		}
		//find the max value of all the columns
		int maxColumnindex=0;
		int maxColumnvalue=0;
		for(int j=0;j<columns;j++) {
			int columnsum=0;
			for(int i=0;i<rows;i++) {
				columnsum+=tarrays[i][j];
			}
			if(columnsum>maxColumnvalue) {
				maxColumnindex=j+1;
				maxColumnvalue=columnsum;
			}
			
		}
		System.out.println("The index of the largest row: "+maxRowindex);
		System.out.println("The index of the largest column:"+maxColumnindex);

		sc.close();

	}
	

}
