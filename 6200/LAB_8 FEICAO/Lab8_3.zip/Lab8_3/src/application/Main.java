package application;
	
import java.util.Random;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;




public class Main extends Application {
	
	@Override
	public void start(Stage primaryStage) throws Exception {
		GridPane gpane=new GridPane();
		gpane.setAlignment(Pos.CENTER);
		gpane.setPadding(new Insets(10));
		gpane.setHgap(10);
		gpane.setVgap(10);
		
		Random r=new Random();
		for(int i=0;i<10;i++) {
			for(int j=0;j<10;j++) {
				int value=r.nextInt(2);
				
				TextField tf=new TextField(String.valueOf(value));
				tf.setPrefWidth(30);
				tf.setPrefHeight(30);
				tf.setAlignment(Pos.CENTER);
				
				
				gpane.add(tf, i, j);
			}
		}
		
		Scene scene=new Scene(gpane);
		primaryStage.setScene(scene);
		primaryStage.setTitle("Lab8_3,FEICAO");
		primaryStage.show();
		
	}
	public static void main(String[] args) {
		launch(args);
	}
}
	

	    
	    